/**
 *
 * @author {}
 */

var selectedData = null;
function toMiladiOnlyDate(shamsiDate){
    var dataAndTime= shamsiDate.split(" ");
    var date;

    if (dataAndTime[1]){
        var time=dataAndTime[1];
        date=splitdatetomiladi(dataAndTime[0]);
        return date+"T"+time;
    }
    else{
        return splitdatetomiladi(shamsiDate);
    }
}

function splitdatetomiladi(date){
    var spdate=date.split("/");
    spdate=toGregorian(parseFloat(spdate[0]),parseFloat(spdate[1]),parseFloat(spdate[2]));
    var gregorianDate= spdate.gy+"-"+((spdate.gm<10)?("0"+spdate.gm):(spdate.gm))+"-"+((spdate.gd<10)?("0"+spdate.gd):(spdate.gd));
    return gregorianDate;
}


function toJAlaliOnlyDate(jalaliDate){
    var dataAndTime= jalaliDate.split("T");
    if (dataAndTime[1]){
        return splitdatetojalali(dataAndTime[0])+" "+dataAndTime[1].split(".")[0];
    }
    else return splitdatetojalali(jalaliDate);
}


function splitdatetojalali(jalaliDate){
    var spdate = jalaliDate.split("-");
    var jalali=toJalaali(parseFloat(spdate[0]),parseFloat(spdate[1]),parseFloat(spdate[2]));
    return jalali.jy+"/"+jalali.jm+"/"+jalali.jd;
}